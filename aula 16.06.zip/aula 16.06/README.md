Dependências instaladas no Terminal:

- Express 
"npm install express"

- My Sql 2 
"npm install mysql2"

- Multer 
"npm install multer"

- Dotenv 
"npm install dotenv"
